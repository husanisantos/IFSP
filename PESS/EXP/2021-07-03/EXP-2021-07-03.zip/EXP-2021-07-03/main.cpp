/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Husani Santos <husani.santos@aluno.ifsp.edu.br>
 *
 * Created on 13 de julho de 2021, 02:16
 */

#include <cstdlib>
#include <iostream>
#include <cstring>
#include <locale>

#define NALUNO 3

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    setlocale(LC_ALL, "Portuguese");
    
    struct EstruturaAluno {
        char nome[60];
        char matricula[10];
        int anoIngresso;
    } strAluno[NALUNO];
    
    int i;
    
    for(i = 0; i < NALUNO; i++) {
        cout <<  "Informe o nome do aluno: ";
        cin.getline(strAluno[i].nome, 60);
        cout <<  "Informe a matrícula do aluno: ";
        cin.getline(strAluno[i].matricula, 10);
        cout <<  "Informe o ano de ingresso do aluno: ";
        cin >>  strAluno[i].anoIngresso;
        cout << endl;
        getchar();
    }
    
    cout << endl << "Alunos cadastrados com sucesso!" << endl;
            
     for(i = 0; i < NALUNO; i++) {
         cout << "Aluno: " << strAluno[i].nome << endl;
         cout << "Matricula: " << strAluno[i].matricula << endl;
         cout << "Ano de ingresso: " << strAluno[i].anoIngresso <<  endl << endl << endl;
     }
    return 0;
}

