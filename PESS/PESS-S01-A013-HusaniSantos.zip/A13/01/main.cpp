/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Husani Santos <husani.santos@aluno.ifsp.edu.br>
 *
 * Created on 19 de julho de 2021, 23:06
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <locale>

using namespace std;

/*
 * 
 */


/* 
 * --------------------------------------------------------------- 
 * Função de conversão de temperatura ºF para ºC 
 * ---------------------------------------------------------------
 */
float converter_temperatura(float fahrenheit) {
    return (fahrenheit - 32) / 1.8;
}

int main(int argc, char** argv) {

    cout.precision(2);
    
    float temperatura;
    
    setlocale(LC_ALL, "Portuguese");
    
    cout << "***************************************" << endl;
    cout << "* CONVERSOR DE TEMPERATURA (°F => ºC) *" << endl;
    cout << "* ----------------------------------- *"  << endl;
    cout << "*      IFSP - CAMPUS VOTUPORANGA      *"  << endl;
    cout << "*    PROF. DR. IVAN OLIVEIRA LOPES    *"  << endl;
    cout << "*         DEV. HUSANI SANTOS          *"  << endl;
    cout << "****************************************" << endl;
 
    cout << "Informe uma temperatura em Fahrenheit: ";
    cin   >> temperatura;
    cout << "ºF : " << temperatura << endl;
    cout << "ºC : " << converter_temperatura(temperatura);
    
    return 0;
}

